t = float(input('nhập hiện độ hiện đại : '))

if t>30:
    print('thời tiết nóng')
elif t<20:
    print('thời tiết lạnh')
else:
    print('thời tiết dễ chịu')