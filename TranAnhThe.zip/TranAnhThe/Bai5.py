n = float(input('số km đã đi được : '))

if n<=1:
    tien = n*7000
elif n<=5:
    tien = 7000*1
    tien += n*6500
else:
    tien = 7000 + 4*6500 + (n-5)*6000

print(f'số tiền cần trả là:{tien:.0f}')