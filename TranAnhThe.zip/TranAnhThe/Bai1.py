a = int(input('nhập số nguyên thứ nhất vào đây: '))
b = int(input('nhập số nguyên thứ hai vào đây: '))
c = int(input('nhập số nguyên thứ ba vào đây: '))

min_number=min(a,b,c)
print('số nhỏ nhất là: ',min_number)

