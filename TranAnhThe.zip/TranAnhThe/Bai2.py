n = int(input('Nhập vào số nguyên N : '))

if (n%4==0 and n%100==0) or (n%400==0):
    print('n là số dương')
else:
    print('n là số âm')
