n1 = input('bạn hãy nhập mật khẩu mới : ')
n2 = input('bạn hãy xác nhận nhập mật khẩu mới lần 2 : ')

if n1==n2:
    print('Mật khẩu đã được đổi thành công')
else:
    print('Mật khẩu không giống nhau rồi')